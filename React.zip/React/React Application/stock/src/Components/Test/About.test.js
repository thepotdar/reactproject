import React from 'react';
import { render, screen } from '@testing-library/react';
import About from '../About';

describe('About Component', () => {
  test('renders About page heading', () => {
    render(<About />);
    const headingElement = screen.getByText(/About Us/i);
    expect(headingElement).toBeInTheDocument();
  });

  test('renders paragraphs with expected text', () => {
    render(<About />);
    const paragraph1 = screen.getByText(/Welcome Sir About page!/i);
    const paragraph2 = screen.getByText(
    
    );

    expect(paragraph1).toBeInTheDocument();
    expect(paragraph2).toBeInTheDocument();
  });
});
