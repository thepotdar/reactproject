

import React from 'react';

const About = () => {
  return (
    <div>
      <h2>About Us</h2>
      <p>
        Welcome to our About page! How we can help you
      </p>
      <p>
      We are providing you the best services.
      </p>
    </div>
  );
};

export default About;
